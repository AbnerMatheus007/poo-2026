package biblioteca;

import java.util.List;
import java.util.Scanner;

public class ProgramaPrincipal {

    public static void main(String[] args) {
        SistemaLivro sistema = new SistemaLivro();
        Scanner scanner = new Scanner(System.in);

        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   SISTEMA DE GERENCIAMENTO DE        ║");
        System.out.println("║           BIBLIOTECA - POO           ║");
        System.out.println("╚══════════════════════════════════════╝");

        boolean rodando = true;

        while (rodando) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Cadastrar livro");
            System.out.println("2. Buscar livro por ISBN");
            System.out.println("3. Listar todos os livros");
            System.out.println("4. Remover livro por ISBN");
            System.out.println("5. Ver total de livros");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = -1;
            try {
                opcao = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida! Digite um número.");
                continue;
            }

            switch (opcao) {
                case 1 -> cadastrarLivro(sistema, scanner);
                case 2 -> buscarLivro(sistema, scanner);
                case 3 -> listarLivros(sistema);
                case 4 -> removerLivro(sistema, scanner);
                case 5 -> System.out.println("Total de livros: " + sistema.totalDeLivros());
                case 0 -> {
                    System.out.println("Encerrando. Até logo!");
                    rodando = false;
                }
                default -> System.out.println("Opção inválida!");
            }
        }

        scanner.close();
    }

    private static void cadastrarLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n-- Cadastrar Novo Livro --");

        System.out.print("Título: ");
        String titulo = scanner.nextLine().trim();

        System.out.print("Autor: ");
        String autor = scanner.nextLine().trim();

        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();

        int ano = 0;
        System.out.print("Ano de publicação: ");
        try {
            ano = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Ano inválido! Registrado como 0.");
        }

        double preco = 0.0;
        System.out.print("Preço (ex: 49.90): ");
        try {
            preco = Double.parseDouble(scanner.nextLine().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            System.out.println("Preço inválido! Registrado como 0.00.");
        }

        Livro livro = new Livro(titulo, autor, isbn, ano, preco);

        try {
            sistema.adicionarLivro(livro);
            System.out.println("Livro cadastrado com sucesso!");
            System.out.println(livro);
        } catch (LivroJaExisteException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void buscarLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n-- Buscar Livro por ISBN --");
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();

        try {
            Livro encontrado = sistema.buscarPorIsbn(isbn);
            System.out.println("Livro encontrado: " + encontrado);
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void listarLivros(SistemaLivro sistema) {
        List<Livro> lista = sistema.listarTodos();
        System.out.println("\n-- Lista de Livros --");
        if (lista.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
        } else {
            for (int i = 0; i < lista.size(); i++) {
                System.out.println((i + 1) + ". " + lista.get(i));
            }
        }
    }

    private static void removerLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n-- Remover Livro por ISBN --");
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();

        try {
            sistema.removerLivro(isbn);
            System.out.println("Livro removido com sucesso!");
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
