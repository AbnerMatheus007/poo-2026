package biblioteca;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SistemaLivroTest {

    private SistemaLivro sistema;
    private Livro livro1;
    private Livro livro2;

    @BeforeEach
    void setUp() {
        sistema = new SistemaLivro();
        livro1 = new Livro("Dom Casmurro", "Machado de Assis", "978-8535902778", 1899, 35.90);
        livro2 = new Livro("O Alquimista", "Paulo Coelho", "978-8532511010", 1988, 42.00);
    }

    @Test
    void deveAdicionarLivroComSucesso() throws LivroJaExisteException {
        sistema.adicionarLivro(livro1);
        assertEquals(1, sistema.totalDeLivros());
    }

    @Test
    void deveLancarExcecaoAoAdicionarDuplicado() throws LivroJaExisteException {
        sistema.adicionarLivro(livro1);
        assertThrows(LivroJaExisteException.class, () -> sistema.adicionarLivro(livro1));
    }

    @Test
    void deveBuscarPorIsbn() throws LivroJaExisteException, LivroNaoEncontradoException {
        sistema.adicionarLivro(livro1);
        assertEquals(livro1, sistema.buscarPorIsbn("978-8535902778"));
    }

    @Test
    void deveLancarExcecaoIsbnInexistente() {
        assertThrows(LivroNaoEncontradoException.class, () -> sistema.buscarPorIsbn("000"));
    }

    @Test
    void deveRemoverLivro() throws LivroJaExisteException, LivroNaoEncontradoException {
        sistema.adicionarLivro(livro1);
        sistema.removerLivro("978-8535902778");
        assertEquals(0, sistema.totalDeLivros());
    }

    @Test
    void livroAntigo1899DeveSerClassico() {
        assertTrue(livro1.ehClassico());
    }

    @Test
    void livroModerno1988NaoDeveSerClassico() {
        assertFalse(livro2.ehClassico());
    }
}
