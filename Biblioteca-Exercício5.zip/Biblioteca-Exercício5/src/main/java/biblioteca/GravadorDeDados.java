package biblioteca;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Responsável por salvar e recuperar os dados do sistema em arquivo,
 * usando serialização Java (ObjectOutputStream / ObjectInputStream).
 */
public class GravadorDeDados {

    private static final String ARQUIVO_LIVROS =
            System.getProperty("user.home") + File.separator + "livros.dat";

    /**
     * Recupera o mapa de livros a partir do arquivo salvo.
     *
     * @return mapa de livros com ISBN como chave
     * @throws IOException se o arquivo não existir ou ocorrer erro de leitura
     */
    public HashMap<String, Livro> recuperarLivros() throws IOException {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(ARQUIVO_LIVROS))) {
            return (HashMap<String, Livro>) ois.readObject();
        } catch (ClassNotFoundException e) {
            throw new IOException("Erro ao recuperar livros: " + e.getMessage());
        }
    }

    /**
     * Salva o mapa de livros no arquivo.
     *
     * @param livros mapa de livros a ser salvo
     * @throws IOException se ocorrer erro de escrita
     */
    public void salvarLivros(Map<String, Livro> livros) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(ARQUIVO_LIVROS))) {
            oos.writeObject(livros);
        }
    }
}
