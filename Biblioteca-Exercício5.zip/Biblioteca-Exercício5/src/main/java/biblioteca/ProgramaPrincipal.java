package biblioteca;

import java.io.IOException;
import java.util.Collection;
import java.util.Scanner;

public class ProgramaPrincipal {

    public static void main(String[] args) {
        SistemaLivro sistema = new SistemaLivro();
        Scanner scanner = new Scanner(System.in);

        // Tenta recuperar dados salvos anteriormente
        try {
            sistema.recuperarDados();
            System.out.println("✔ Dados recuperados com sucesso!");
        } catch (IOException e) {
            System.out.println("Nenhum dado salvo encontrado. Iniciando sistema vazio.");
        }

        boolean continuar = true;
        while (continuar) {
            System.out.println("\n====== SISTEMA DE BIBLIOTECA ======");
            System.out.println("1 - Cadastrar livro");
            System.out.println("2 - Buscar livro por ISBN");
            System.out.println("3 - Listar todos os livros");
            System.out.println("4 - Remover livro");
            System.out.println("5 - Salvar e sair");
            System.out.print("Escolha uma opção: ");

            String opcao = scanner.nextLine().trim();

            switch (opcao) {
                case "1" -> cadastrarLivro(sistema, scanner);
                case "2" -> buscarLivro(sistema, scanner);
                case "3" -> listarLivros(sistema);
                case "4" -> removerLivro(sistema, scanner);
                case "5" -> {
                    salvarESair(sistema);
                    continuar = false;
                }
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        }

        scanner.close();
    }

    private static void cadastrarLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n--- Cadastrar Livro ---");
        System.out.print("Título: ");
        String titulo = scanner.nextLine();

        System.out.print("Autor: ");
        String autor = scanner.nextLine();

        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();

        System.out.print("Ano de publicação: ");
        int ano = 0;
        try {
            ano = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Ano inválido! Usando 0.");
        }

        System.out.print("Preço: ");
        double preco = 0;
        try {
            preco = Double.parseDouble(scanner.nextLine().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            System.out.println("Preço inválido! Usando 0.");
        }

        try {
            sistema.adicionarLivro(new Livro(titulo, autor, isbn, ano, preco));
            System.out.println("✔ Livro cadastrado com sucesso!");
        } catch (LivroJaExisteException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void buscarLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n--- Buscar Livro por ISBN ---");
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        try {
            Livro livro = sistema.buscarPorIsbn(isbn);
            System.out.println("Livro encontrado: " + livro);
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void listarLivros(SistemaLivro sistema) {
        System.out.println("\n--- Lista de Livros ---");
        Collection<Livro> livros = sistema.listarTodos();
        if (livros.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
        } else {
            int i = 1;
            for (Livro l : livros) {
                System.out.println(i++ + ". " + l);
            }
        }
    }

    private static void removerLivro(SistemaLivro sistema, Scanner scanner) {
        System.out.println("\n--- Remover Livro ---");
        System.out.print("ISBN do livro a remover: ");
        String isbn = scanner.nextLine().trim();
        try {
            sistema.removerLivro(isbn);
            System.out.println("✔ Livro removido com sucesso!");
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void salvarESair(SistemaLivro sistema) {
        try {
            sistema.salvarDados();
            System.out.println("✔ Dados salvos com sucesso! Encerrando...");
        } catch (IOException e) {
            System.out.println("Erro ao salvar dados: " + e.getMessage());
        }
    }
}
