package biblioteca;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class SistemaLivro implements SistemaBiblioteca {

    private Map<String, Livro> livros;
    private GravadorDeDados gravador;

    public SistemaLivro() {
        this.livros = new HashMap<>();
        this.gravador = new GravadorDeDados();
    }

    @Override
    public void adicionarLivro(Livro livro) throws LivroJaExisteException {
        if (livros.containsKey(livro.getIsbn())) {
            throw new LivroJaExisteException("Livro com ISBN " + livro.getIsbn() + " já cadastrado.");
        }
        livros.put(livro.getIsbn(), livro);
    }

    @Override
    public Livro buscarPorIsbn(String isbn) throws LivroNaoEncontradoException {
        Livro livro = livros.get(isbn);
        if (livro == null) {
            throw new LivroNaoEncontradoException("Livro com ISBN " + isbn + " não encontrado.");
        }
        return livro;
    }

    @Override
    public Collection<Livro> listarTodos() {
        return livros.values();
    }

    @Override
    public void removerLivro(String isbn) throws LivroNaoEncontradoException {
        if (!livros.containsKey(isbn)) {
            throw new LivroNaoEncontradoException("Livro com ISBN " + isbn + " não encontrado.");
        }
        livros.remove(isbn);
    }

    @Override
    public void salvarDados() throws IOException {
        gravador.salvarLivros(livros);
    }

    @Override
    public void recuperarDados() throws IOException {
        livros = gravador.recuperarLivros();
    }
}
