package biblioteca;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.Collection;

public class SistemaLivroTest {

    SistemaLivro sistema;

    @BeforeEach
    void setUp() {
        this.sistema = new SistemaLivro();
    }

    @Test
    void testAdicionarEBuscarLivro() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        try {
            sistema.adicionarLivro(livro);
            Livro encontrado = sistema.buscarPorIsbn("978-1");
            assertEquals("Dom Casmurro", encontrado.getTitulo());
            assertEquals("Machado de Assis", encontrado.getAutor());
        } catch (LivroJaExisteException | LivroNaoEncontradoException e) {
            fail("Não deveria lançar exceção");
        }
    }

    @Test
    void testAdicionarLivroJaExistente() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        assertThrows(LivroJaExisteException.class, () -> {
            sistema.adicionarLivro(livro);
            sistema.adicionarLivro(livro);
        });
    }

    @Test
    void testBuscarLivroInexistente() {
        assertThrows(LivroNaoEncontradoException.class, () ->
                sistema.buscarPorIsbn("isbn-inexistente"));
    }

    @Test
    void testRemoverLivro() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        try {
            sistema.adicionarLivro(livro);
            sistema.removerLivro("978-1");
            assertThrows(LivroNaoEncontradoException.class, () ->
                    sistema.buscarPorIsbn("978-1"));
        } catch (LivroJaExisteException | LivroNaoEncontradoException e) {
            fail("Não deveria lançar exceção");
        }
    }

    @Test
    void testRemoverLivroInexistente() {
        assertThrows(LivroNaoEncontradoException.class, () ->
                sistema.removerLivro("isbn-inexistente"));
    }

    @Test
    void testListarTodos() {
        assertTrue(sistema.listarTodos().isEmpty());
        try {
            sistema.adicionarLivro(new Livro("Livro 1", "Autor 1", "isbn-1", 2000, 20.0));
            sistema.adicionarLivro(new Livro("Livro 2", "Autor 2", "isbn-2", 2010, 30.0));
            Collection<Livro> livros = sistema.listarTodos();
            assertEquals(2, livros.size());
        } catch (LivroJaExisteException e) {
            fail("Não deveria lançar exceção");
        }
    }

    @Test
    void testSalvarERecuperarDados() {
        try {
            sistema.adicionarLivro(new Livro("O Alquimista", "Paulo Coelho", "978-2", 1988, 45.0));
            sistema.salvarDados();

            SistemaLivro sistema2 = new SistemaLivro();
            sistema2.recuperarDados();

            Livro recuperado = sistema2.buscarPorIsbn("978-2");
            assertEquals("O Alquimista", recuperado.getTitulo());
            assertEquals("Paulo Coelho", recuperado.getAutor());
        } catch (LivroJaExisteException | LivroNaoEncontradoException | IOException e) {
            fail("Não deveria lançar exceção: " + e.getMessage());
        }
    }

    @Test
    void testEhClassico() {
        Livro classico = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        Livro moderno = new Livro("Clean Code", "Robert Martin", "978-3", 2008, 89.90);
        assertTrue(classico.ehClassico());
        assertFalse(moderno.ehClassico());
    }
}
