# Sistema de Biblioteca com Persistência

Sistema criado para a disciplina de Programação Orientada a Objetos (POO) - 2026.1 do curso de Ciência da Computação na UFPB.

O sistema permite cadastrar e gerenciar livros com título, autor, ISBN, ano de publicação e preço. Os dados são persistidos em arquivo `.dat` via serialização Java, para que não se percam ao fechar o programa.

## Funcionalidades

- Cadastrar livros (título, autor, ISBN, ano, preço)
- Buscar livro pelo ISBN
- Listar todos os livros cadastrados
- Remover livro pelo ISBN
- Verificar se um livro é clássico (mais de 50 anos desde a publicação)
- Salvar e recuperar dados em arquivo (persistência com `ObjectOutputStream` / `ObjectInputStream`)

## Como executar

Abra o arquivo `ProgramaPrincipal.java` na sua IDE (IntelliJ, Eclipse, etc.) e execute-o diretamente, ou pelo terminal:

```bash
mvn compile
mvn exec:java -Dexec.mainClass="biblioteca.ProgramaPrincipal"
```

## Estrutura do projeto

```
src/
├── main/java/biblioteca/
│   ├── SistemaBiblioteca.java        (interface com Javadoc)
│   ├── GravadorDeDados.java          (persistência em arquivo)
│   ├── Livro.java
│   ├── SistemaLivro.java
│   ├── ProgramaPrincipal.java        ← ARQUIVO PARA EXECUTAR
│   ├── LivroJaExisteException.java
│   └── LivroNaoEncontradoException.java
└── test/java/biblioteca/
    └── SistemaLivroTest.java
```

## Tecnologias

- Java 25
- JUnit 5
- Maven

## Autor

Abner Matheus dos Santos Silva
