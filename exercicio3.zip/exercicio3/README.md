# Sistema de Amigo Secreto

Sistema criado para a disciplina de Programação Orientada a Objetos (POO) do curso de Ciência da Computação na UFPB.

A ideia foi criar um sistema para gerenciar uma brincadeira de Amigo Secreto, onde é possível cadastrar participantes, configurar sorteios, enviar mensagens anônimas ou identificadas para todos ou para alguém específico.

## O que o sistema faz

- Cadastrar amigos participantes por nome e e-mail
- Pesquisar amigo pelo e-mail
- Configurar o amigo secreto sorteado de cada participante
- Pesquisar o amigo secreto de um participante
- Enviar mensagens anônimas ou identificadas para todos
- Enviar mensagens anônimas ou identificadas para alguém específico
- Pesquisar todas as mensagens ou apenas as anônimas

## Classes principais

| Classe | Descrição |
|---|---|
| `Amigo` | Representa um participante da brincadeira |
| `Mensagem` | Classe abstrata base para mensagens |
| `MensagemParaTodos` | Mensagem enviada para todos os participantes |
| `MensagemParaAlguem` | Mensagem enviada para um participante específico |
| `SistemaAmigo` | Gerencia amigos e mensagens usando List |
| `SistemaAmigoMap` | Gerencia amigos e mensagens usando HashMap |
| `SistemaAmigoMapTest` | Testes JUnit 5 para a classe SistemaAmigoMap |
| `AmigoInexistenteException` | Exceção para amigo não encontrado |
| `AmigoJaExisteException` | Exceção para amigo duplicado |
| `AmigoNaoSorteadoException` | Exceção para amigo sem sorteio configurado |

## Tecnologias

- Java 17+
- JUnit 5
- Maven

## Autor

Abner Matheus dos Santos Silva
