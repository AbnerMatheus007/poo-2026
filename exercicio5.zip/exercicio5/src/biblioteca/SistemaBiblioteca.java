package biblioteca;

import java.io.IOException;
import java.util.Collection;

/**
 * Interface que define as operações principais do sistema de biblioteca.
 * Permite cadastrar, buscar, listar e remover livros,
 * além de salvar e recuperar dados em arquivo.
 */
public interface SistemaBiblioteca {

    /**
     * Cadastra um novo livro no sistema.
     *
     * @param livro o livro a ser cadastrado
     * @throws LivroJaExisteException se já existir um livro com o mesmo ISBN
     */
    public void adicionarLivro(Livro livro) throws LivroJaExisteException;

    /**
     * Busca um livro pelo ISBN.
     *
     * @param isbn o ISBN do livro
     * @return o livro encontrado
     * @throws LivroNaoEncontradoException se não existir livro com esse ISBN
     */
    public Livro buscarPorIsbn(String isbn) throws LivroNaoEncontradoException;

    /**
     * Retorna todos os livros cadastrados no sistema.
     *
     * @return coleção com todos os livros
     */
    public Collection<Livro> listarTodos();

    /**
     * Remove um livro do sistema pelo ISBN.
     *
     * @param isbn o ISBN do livro a ser removido
     * @throws LivroNaoEncontradoException se não existir livro com esse ISBN
     */
    public void removerLivro(String isbn) throws LivroNaoEncontradoException;

    /**
     * Salva os dados do sistema em arquivo.
     *
     * @throws IOException se ocorrer um erro ao salvar os dados
     */
    public void salvarDados() throws IOException;

    /**
     * Recupera os dados do sistema a partir do arquivo salvo.
     *
     * @throws IOException se ocorrer um erro ao recuperar os dados
     */
    public void recuperarDados() throws IOException;
}
