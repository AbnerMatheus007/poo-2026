package biblioteca;

import java.io.IOException;
import java.util.Collection;
import java.util.Scanner;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        SistemaLivro sistema = new SistemaLivro();
        Scanner scanner = new Scanner(System.in);

        try {
            sistema.recuperarDados();
            System.out.println("Dados recuperados com sucesso!");
        } catch (IOException e) {
            System.out.println("Nenhum dado salvo encontrado. Iniciando sistema vazio.");
        }

        System.out.print("\nQuantos livros deseja cadastrar? ");
        int quantidade = 0;
        try {
            quantidade = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Valor inválido! Encerrando o programa.");
            scanner.close();
            return;
        }

        for (int i = 1; i <= quantidade; i++) {
            System.out.println("\n--- Livro " + i + " ---");

            System.out.print("Título: ");
            String titulo = scanner.nextLine();

            System.out.print("Autor: ");
            String autor = scanner.nextLine();

            System.out.print("ISBN: ");
            String isbn = scanner.nextLine();

            System.out.print("Ano de publicação: ");
            int ano = 0;
            try {
                ano = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ano inválido! Usando 0.");
            }

            System.out.print("Preço: ");
            double preco = 0;
            try {
                preco = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Preço inválido! Usando 0.");
            }

            Livro livro = new Livro(titulo, autor, isbn, ano, preco);
            try {
                sistema.adicionarLivro(livro);
                System.out.println("Livro cadastrado com sucesso!");
            } catch (LivroJaExisteException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }

        System.out.println("\n--- Busca de Livro por ISBN ---");
        System.out.print("Digite o ISBN para buscar: ");
        String isbnBusca = scanner.nextLine();
        try {
            Livro encontrado = sistema.buscarPorIsbn(isbnBusca);
            System.out.println("Livro encontrado: " + encontrado);
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        System.out.println("\n--- Remoção de Livro ---");
        System.out.print("Digite o ISBN do livro a remover: ");
        String isbnRemover = scanner.nextLine();
        try {
            sistema.removerLivro(isbnRemover);
            System.out.println("Livro removido com sucesso!");
        } catch (LivroNaoEncontradoException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        System.out.println("\n=== Lista de Livros Cadastrados ===");
        Collection<Livro> livros = sistema.listarTodos();
        if (livros.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
        } else {
            for (Livro l : livros) {
                System.out.println(l);
            }
        }

        try {
            sistema.salvarDados();
            System.out.println("\nDados salvos com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao salvar dados: " + e.getMessage());
        }

        scanner.close();
    }
}
