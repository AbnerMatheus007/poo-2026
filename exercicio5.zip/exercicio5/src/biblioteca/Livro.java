package biblioteca;

import java.io.Serializable;
import java.util.Objects;

public class Livro implements Serializable {
    private static final long serialVersionUID = 1L;
    private String titulo;
    private String autor;
    private String isbn;
    private int anoPublicacao;
    private double preco;

    public Livro(String titulo, String autor, String isbn, int anoPublicacao, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.anoPublicacao = anoPublicacao;
        this.preco = preco;
    }

    public Livro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public int getAnoPublicacao() { return anoPublicacao; }
    public void setAnoPublicacao(int anoPublicacao) { this.anoPublicacao = anoPublicacao; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    public boolean ehClassico() {
        return (2025 - anoPublicacao) > 50;
    }

    @Override
    public String toString() {
        return "Livro{titulo='" + titulo + "', autor='" + autor + "', isbn='" + isbn +
               "', anoPublicacao=" + anoPublicacao + ", preco=R$" + String.format("%.2f", preco) +
               ", classico=" + ehClassico() + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livro livro = (Livro) o;
        return Objects.equals(isbn, livro.isbn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }
}
