package biblioteca;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class GravadorDeDados {
    public static final String ARQUIVO_LIVROS = "livros.dat";

    public HashMap<String, Livro> recuperarLivros() throws IOException {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(ARQUIVO_LIVROS))) {
            return (HashMap<String, Livro>) ois.readObject();
        } catch (ClassNotFoundException e) {
            throw new IOException("Erro ao recuperar livros: " + e.getMessage());
        }
    }

    public void salvarLivros(Map<String, Livro> livros) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(ARQUIVO_LIVROS))) {
            oos.writeObject(livros);
        }
    }
}
