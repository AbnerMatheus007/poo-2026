package biblioteca;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Collection;

public class SistemaLivroTest {

    SistemaLivro sistema;

    @BeforeEach
    void setUp() {
        this.sistema = new SistemaLivro();
    }

    @Test
    void testAdicionarEBuscarLivro() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        try {
            sistema.adicionarLivro(livro);
            Livro encontrado = sistema.buscarPorIsbn("978-1");
            assertEquals("Dom Casmurro", encontrado.getTitulo());
            assertEquals("Machado de Assis", encontrado.getAutor());
        } catch (LivroJaExisteException | LivroNaoEncontradoException e) {
            fail("Não deveria lançar exceção");
        }
    }

    @Test
    void testAdicionarLivroJaExistente() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        assertThrows(LivroJaExisteException.class, () -> {
            sistema.adicionarLivro(livro);
            sistema.adicionarLivro(livro);
        });
    }

    @Test
    void testBuscarLivroInexistente() {
        assertThrows(LivroNaoEncontradoException.class, () -> {
            sistema.buscarPorIsbn("isbn-inexistente");
        });
    }

    @Test
    void testRemoverLivro() {
        Livro livro = new Livro("Dom Casmurro", "Machado de Assis", "978-1", 1899, 35.90);
        try {
            sistema.adicionarLivro(livro);
            sistema.removerLivro("978-1");
            assertThrows(LivroNaoEncontradoException.class, () -> sistema.buscarPorIsbn("978-1"));
        } catch (LivroJaExisteException | LivroNaoEncontradoException e) {
            fail("Não deveria lançar exceção");
        }
    }

    @Test
    void testListarTodos() {
        assertTrue(sistema.listarTodos().isEmpty());
        try {
            sistema.adicionarLivro(new Livro("Livro 1", "Autor 1", "isbn-1", 2000, 20.0));
            sistema.adicionarLivro(new Livro("Livro 2", "Autor 2", "isbn-2", 2010, 30.0));
            Collection<Livro> livros = sistema.listarTodos();
            assertEquals(2, livros.size());
        } catch (LivroJaExisteException e) {
            fail("Não deveria lançar exceção");
        }
    }
}
