package br.ufpb.dcx.amigosecreto;

import javax.swing.JOptionPane;

public class TestaSistemaAmigoGUI {
    public static void main(String[] args) {
        SistemaAmigo sistema = new SistemaAmigo();

        // b) Lê a quantidade de amigos
        String qtdStr = JOptionPane.showInputDialog("Quantos amigos vão participar?");
        int quantidade = Integer.parseInt(qtdStr);

        // c) Lê e cadastra os amigos
        for (int i = 1; i <= quantidade; i++) {
            String nome = JOptionPane.showInputDialog("Nome do amigo " + i + ":");
            String email = JOptionPane.showInputDialog("E-mail do amigo " + i + ":");
            try {
                sistema.cadastraAmigo(nome, email);
            } catch (AmigoJaExisteException e) {
                JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
            }
        }

        // d) Cadastra os resultados do sorteio
        for (int i = 1; i <= quantidade; i++) {
            String emailPessoa = JOptionPane.showInputDialog("E-mail do amigo " + i + ":");
            String emailSorteado = JOptionPane.showInputDialog("E-mail do amigo secreto de " + i + ":");
            try {
                sistema.configuraAmigoSecretoDe(emailPessoa, emailSorteado);
            } catch (AmigoInexistenteException e) {
                JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
            }
        }

        // e) Envia mensagem para todos
        String remetente = JOptionPane.showInputDialog("E-mail do remetente da mensagem para todos:");
        String texto = JOptionPane.showInputDialog("Texto da mensagem:");
        String anonimaStr = JOptionPane.showInputDialog("A mensagem é anônima? (sim/não)");
        boolean anonima = anonimaStr.equalsIgnoreCase("sim");

        sistema.enviarMensagemParaTodos(texto, remetente, anonima);
        JOptionPane.showMessageDialog(null, "Mensagem enviada para todos!");
    }
}
