package br.ufpb.dcx.amigosecreto;

import java.util.ArrayList;
import java.util.List;

public class SistemaAmigo {
    private List<Amigo> amigos;
    private List<Mensagem> mensagens;

    public SistemaAmigo() {
        this.amigos = new ArrayList<>();
        this.mensagens = new ArrayList<>();
    }

    public void cadastraAmigo(String nome, String email) throws AmigoJaExisteException {
        for (Amigo a : amigos) {
            if (a.getEmail().equals(email)) {
                throw new AmigoJaExisteException("Amigo com e-mail " + email + " já existe.");
            }
        }
        amigos.add(new Amigo(nome, email));
    }

    public Amigo pesquisaAmigo(String email) throws AmigoInexistenteException {
        for (Amigo a : amigos) {
            if (a.getEmail().equals(email)) {
                return a;
            }
        }
        throw new AmigoInexistenteException("Amigo com e-mail " + email + " não encontrado.");
    }

    public void configuraAmigoSecretoDe(String emailDaPessoa, String emailAmigoSorteado)
            throws AmigoInexistenteException {
        Amigo amigo = pesquisaAmigo(emailDaPessoa);
        amigo.setEmailAmigoSecreto(emailAmigoSorteado);
    }

    public String pesquisaAmigoSecretoDe(String emailDaPessoa)
            throws AmigoInexistenteException, AmigoNaoSorteadoException {
        Amigo amigo = pesquisaAmigo(emailDaPessoa);
        if (amigo.getEmailAmigoSecreto() == null) {
            throw new AmigoNaoSorteadoException("Amigo secreto de " + emailDaPessoa + " ainda não foi sorteado.");
        }
        return amigo.getEmailAmigoSecreto();
    }

    public void enviarMensagemParaAlguem(String texto, String emailRemetente,
                                          String emailDestinatario, boolean anonima) {
        mensagens.add(new MensagemParaAlguem(texto, emailRemetente, emailDestinatario, anonima));
    }

    public void enviarMensagemParaTodos(String texto, String emailRemetente, boolean anonima) {
        mensagens.add(new MensagemParaTodos(texto, emailRemetente, anonima));
    }

    public List<Mensagem> pesquisaMensagensAnonimas() {
        List<Mensagem> anonimas = new ArrayList<>();
        for (Mensagem m : mensagens) {
            if (m.isAnonima()) {
                anonimas.add(m);
            }
        }
        return anonimas;
    }

    public List<Mensagem> pesquisaTodasAsMensagens() {
        return new ArrayList<>(mensagens);
    }

    public List<Amigo> getAmigos() {
        return amigos;
    }

    public void sortear() {
        List<Amigo> disponiveis = new ArrayList<>(amigos);
        for (Amigo amigo : amigos) {
            Amigo sorteado;
            do {
                int pos = (int) (Math.random() * disponiveis.size());
                sorteado = disponiveis.get(pos);
            } while (sorteado.getEmail().equals(amigo.getEmail()) && disponiveis.size() > 1);
            amigo.setEmailAmigoSecreto(sorteado.getEmail());
            disponiveis.remove(sorteado);
        }
    }
}
