package br.ufpb.dcx.amigosecreto;

import java.util.List;

public class TestaSistemaAmigo {
    public static void main(String[] args) {
        SistemaAmigo sistema = new SistemaAmigo();

        try {
            // a) Cadastra dois amigos
            sistema.cadastraAmigo("José", "jose@email.com");
            sistema.cadastraAmigo("Maria", "maria@email.com");

            // b) Configura amigos secretos
            sistema.configuraAmigoSecretoDe("jose@email.com", "maria@email.com");
            sistema.configuraAmigoSecretoDe("maria@email.com", "jose@email.com");

            // c) Mensagem anônima de Maria para José
            sistema.enviarMensagemParaAlguem("Oi José!", "maria@email.com", "jose@email.com", true);

            // d) Mensagem anônima de Maria para todos
            sistema.enviarMensagemParaTodos("Feliz Natal a todos!", "maria@email.com", true);

            // e) Pesquisa e imprime mensagens anônimas
            List<Mensagem> anonimas = sistema.pesquisaMensagensAnonimas();
            for (Mensagem m : anonimas) {
                System.out.println(m.getTextoCompletoAExibir());
            }

            // f) Verifica amigo secreto de José
            String emailAmigoDeJose = sistema.pesquisaAmigoSecretoDe("jose@email.com");
            if (emailAmigoDeJose.equals("maria@email.com")) {
                System.out.println("Ok");
            }

        } catch (AmigoJaExisteException | AmigoInexistenteException | AmigoNaoSorteadoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
