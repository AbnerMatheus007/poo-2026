package biblioteca;

import java.util.Scanner;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        SistemaLivro sistema = new SistemaLivro();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantos livros deseja cadastrar? ");
        int quantidade = 0;

        try {
            quantidade = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Valor inválido! Encerrando o programa.");
            scanner.close();
            return;
        }

        for (int i = 1; i <= quantidade; i++) {
            System.out.println("\n--- Livro " + i + " ---");

            System.out.print("Título: ");
            String titulo = scanner.nextLine();

            System.out.print("Autor: ");
            String autor = scanner.nextLine();

            System.out.print("ISBN: ");
            String isbn = scanner.nextLine();

            System.out.print("Ano de publicação: ");
            int ano = 0;
            try {
                ano = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ano inválido! Usando 0.");
            }

            System.out.print("Preço: ");
            double preco = 0;
            try {
                preco = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Preço inválido! Usando 0.");
            }

            Livro livro = new Livro(titulo, autor, isbn, ano, preco);

            try {
                sistema.adicionarLivro(livro);
                System.out.println("Livro adicionado com sucesso!");
            } catch (LivroJaExisteException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }

        System.out.println("\n=== Lista de Livros Cadastrados ===");
        for (Livro l : sistema.listarTodos()) {
            System.out.println(l);
        }

        scanner.close();
    }
}
