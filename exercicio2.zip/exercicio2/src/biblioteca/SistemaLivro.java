package biblioteca;

import java.util.ArrayList;
import java.util.List;

public class SistemaLivro {
    private List<Livro> livros;

    public SistemaLivro() {
        this.livros = new ArrayList<>();
    }

    public void adicionarLivro(Livro livro) throws LivroJaExisteException {
        for (Livro l : livros) {
            if (l.equals(livro)) {
                throw new LivroJaExisteException("Livro com ISBN " + livro.getIsbn() + " já cadastrado.");
            }
        }
        livros.add(livro);
    }

    public Livro buscarPorIsbn(String isbn) throws LivroNaoEncontradoException {
        for (Livro l : livros) {
            if (l.getIsbn().equals(isbn)) {
                return l;
            }
        }
        throw new LivroNaoEncontradoException("Livro com ISBN " + isbn + " não encontrado.");
    }

    public List<Livro> listarTodos() {
        return new ArrayList<>(livros);
    }

    public void removerLivro(String isbn) throws LivroNaoEncontradoException {
        Livro livro = buscarPorIsbn(isbn);
        livros.remove(livro);
    }
}
