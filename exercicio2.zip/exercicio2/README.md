# Sistema de Biblioteca

Sistema criado para a disciplina de Programação Orientada a Objetos (POO) do curso de Ciência da Computação na UFPB.

A ideia foi criar um sistema simples para cadastrar e gerenciar livros, onde é possível adicionar um livro informando título, autor, ISBN, ano de publicação e preço. O sistema também permite pesquisar e remover livros, além de verificar se um livro é considerado clássico (mais de 50 anos).

## O que o sistema faz

- Cadastrar livros com título, autor, ISBN, ano de publicação e preço
- Buscar livro pelo ISBN
- Listar todos os livros cadastrados
- Remover livro pelo ISBN
- Verificar se o livro é um clássico (mais de 50 anos desde a publicação)
- Tratamento de exceções para entradas inválidas e livros duplicados

## Classes principais

| Classe | Descrição |
|---|---|
| `Livro` | Representa um livro com atributos, gets/sets, toString, equals e hashCode |
| `SistemaLivro` | Gerencia a lista de livros e lança exceções personalizadas |
| `ProgramaPrincipal` | Programa principal que instancia e usa as classes do sistema |
| `LivroJaExisteException` | Exceção lançada ao tentar cadastrar um livro já existente |
| `LivroNaoEncontradoException` | Exceção lançada quando o livro buscado não é encontrado |

## Diagrama de Classes

![Diagrama de Classes](diagrama-classes.png)

## Autor

Abner Matheus dos Santos Silva
